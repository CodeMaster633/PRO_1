package application.model;

public enum PladsType {
    STANDART,EKSTRABEN,KØRESTOL
}
