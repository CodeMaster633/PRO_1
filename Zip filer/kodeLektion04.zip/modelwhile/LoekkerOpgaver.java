package modelwhile;

public class LoekkerOpgaver {

    public static void main(String[] args) {

//        Kald af metoder der afprøver opgave 1

//        System.out.println(summerEven(100));
//        System.out.println(summerSquare(10));
//        System.out.println(sumOdd(3, 19));
//        allPowers(20);

    }

    // Metoden returnerer summen af alle lige tal mellem 2 og n
    public static int summerEven(int n) {
        // TODO Opgave 1.a
        return -1;
    }

    // Metoden returnerer summen af alle kvdrater mellem 1*1 og n*n
    public static int summerSquare(int n) {
        // TODO Opgave 1.b
        return -1;
    }

    // Metoden returnerer summen af alle ulige tal mellem a og b
    public static int sumOdd(int a, int b) {
        // TODO Opgave 1.c
        return -1;
    }

    // Metoden udskriver 2 potenser fra  f
    public static void allPowers(int n) {
        // TODO Opgave 1.d
    }


}
