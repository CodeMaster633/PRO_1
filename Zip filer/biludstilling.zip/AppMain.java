import javafx.application.Application;

public class AppMain {

    public static void main(String[] args) {
        Application.launch(AppGUI.class);
    }
}