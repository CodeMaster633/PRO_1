public interface Pencil {

    public void drawCar(Car car);
}